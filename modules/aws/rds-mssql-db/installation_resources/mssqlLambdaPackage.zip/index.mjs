const { spawnSync } = import('child_process');
export const handler = async (event) => {
  const command = 'sqlcmd';
  const args = [
    '-S', 'hadar-mssql-db.cbcilhr0rnbx.us-east-2.rds.amazonaws.com',
    '-d', 'financedb',
    '-i', 'sqlcmdTest.sql',
    '-U', 'admin', 
    '-P', 'Barbapapa123',
  ];
  const options = {};
  const result = spawnSync(command, args, options);
  console.log(result.stdout.toString());
  console.error(result.stderr.toString());
  return {};
};





// const { spawnSync } = import('child_process');

// // import { S3 as S3Client } from 'aws-sdk'

// // const AWS = import('aws-sdk');
// // const s3 = new AWS.S3();

// export const handler = async (event) => {
//     console.info("Starting lambda");
    
//     // read sql file from s3
//     // const { spawnSync } = require('child_process');
//     // var AWS = import("aws-sdk");
//     // import * as AWS from 'aws-sdk';
//     // const s3 = new AWS.S3();
//     // var s3 = new AWS.S3({apiVersion: '2006-03-01'});
//     // var params = {Bucket: 'hadar-mssql', Key: 'mssql_sqlcmd_traffic.sql'};
//     // var s3file = s3.getObject(params, function(err, data) {
//     //   if (err) console.log(err, err.stack); // an error occurred
//     //   else     console.log(data);           // successful response
//     // });
//     // console.log("s3file is:");
//     // console.log(s3file);
    
//     // // Build the sqlcmd command with the necessary arguments
//     const command = ['sqlcmd', '-S', 'hadar-mssql-db.cbcilhr0rnbx.us-east-2.rds.amazonaws.com', '-d', 'financedb', '-U', 'admin', '-P', 'Barbapapa123', '-i', 'sqlcmdTest.sql'];

//     // // Execute the command and capture the output
//     const output = spawnSync('sqlcmd', command, { encoding: 'utf-8' });

//     // // Print the output
//     console.log(output.stdout);
    
//     console.info("lambda completed successfully");
// };