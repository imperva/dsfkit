import math
import random
from itertools import islice
import os
import pyodbc

def lambda_handler(event, context):
    print("beginning of lambda")
    
    connString = createConnString()
    print("connString is ", connString)

    enableAuditOnServer(connString)

    finance_fast_execute(connString)
    health_fast_execute(connString)
    insurance_fast_execute(connString)
    telecom_fast_execute(connString)


def createConnString():
    dbUrl  = os.environ['DB_URI']
    dbPort = os.environ['DB_PORT']
    dbName = os.environ['DB_NAME']
    dbUser = os.environ['DB_USER']
    dbPwd  = os.environ['DB_PWD']

    return "DRIVER={ODBC Driver 17 for SQL Server}; SERVER="+dbUrl+";Encrypt=no;TrustServerCertificate=yes;PORT="+dbPort+";DATABASE="+dbName+";UID="+dbUser+";LongAsMax=yes;PWD="+dbPwd+";"


def enableAuditOnServer(connString):
    queries = [
        "USE master;",
        r"CREATE SERVER AUDIT edsf_audit TO FILE ( FILEPATH = 'D:\rdsdbdata\SQLAudit', MAXSIZE = 2MB ) WHERE [database_name] <> 'rdsadmin' AND [client_ip] <> 'local machine';",
        "ALTER SERVER AUDIT edsf_audit WITH ( STATE = ON );",
        "CREATE SERVER AUDIT SPECIFICATION edsf_server_audit_specification FOR SERVER AUDIT edsf_audit " + \
        "ADD ( AUDIT_CHANGE_GROUP )," + \
        "ADD ( DATABASE_CHANGE_GROUP )," + \
        "ADD ( DATABASE_PRINCIPAL_IMPERSONATION_GROUP )," + \
        "ADD ( FAILED_DATABASE_AUTHENTICATION_GROUP )," + \
        "ADD ( FAILED_LOGIN_GROUP )," + \
        "ADD ( SERVER_OBJECT_CHANGE_GROUP )," + \
        "ADD ( SERVER_PRINCIPAL_IMPERSONATION_GROUP )," + \
        "ADD ( SUCCESSFUL_DATABASE_AUTHENTICATION_GROUP )," + \
        "ADD ( SUCCESSFUL_LOGIN_GROUP )" + \
        "WITH ( STATE = ON );"
    ]
    
    with pyodbc.connect(connString, autocommit=True) as conn:
        with conn.cursor() as crsr:
            for q in queries:
                crsr.execute(q)


def finance_fast_execute(connString):
    # run the mssql script queries
    auditPerDBQuery = getAuditPerDBQuery("financedb")
    queries = [
        "CREATE DATABASE financedb;",
        "CREATE LOGIN Teller with password = 'Barbapapa123';",
        "USE financedb;",
        auditPerDBQuery,
        "CREATE USER Teller from login Teller;",
        "GRANT CONNECT TO Teller;",
        "CREATE TABLE CreditCard(CreditCardID int IDENTITY (1, 1) NOT NULL, CardType nvarchar(50) NOT NULL, CardNumber BIGINT NOT NULL, ExpMonth int NOT NULL, ExpYear int NOT NULL, Name nvarchar(50));"
    ]
    
    with pyodbc.connect(connString, autocommit=True) as conn:
        with conn.cursor() as crsr:
            for q in queries:
                crsr.execute(q)
            count = 10000
            params = list(islice(create_credit_card_record(), count))
            crsr.fast_executemany = True
            q ='''INSERT INTO CreditCard values(?, ?, ?, ?, ?)'''
            crsr.executemany(q, params)

    # run the updated mssql queries
    updatedQueries = [
        "USE financedb;",
        "ALTER TABLE CreditCard ADD Comments text;",
        "ALTER TABLE CreditCard ADD CreditReport text;"
    ]
    updateCommentsColumn('CreditCard', 'CreditCardID', updatedQueries, connString)


def getAuditPerDBQuery(dbName):
    return "CREATE DATABASE AUDIT SPECIFICATION edsf_database_audit_specification_" + dbName + " FOR SERVER AUDIT edsf_audit " + \
    "ADD (AUDIT_CHANGE_GROUP), " + \
    "ADD (DATABASE_CHANGE_GROUP), " + \
    "ADD (DATABASE_OBJECT_CHANGE_GROUP), " + \
    "ADD (DATABASE_PERMISSION_CHANGE_GROUP), " + \
    "ADD (DATABASE_PRINCIPAL_IMPERSONATION_GROUP), " + \
    "ADD (FAILED_DATABASE_AUTHENTICATION_GROUP), " +   \
    "ADD (SUCCESSFUL_DATABASE_AUTHENTICATION_GROUP), " + \
    "ADD ( SELECT, UPDATE, INSERT, DELETE, EXECUTE, RECEIVE, REFERENCES ON database::" + dbName + " BY public ) " + \
    "WITH ( STATE = ON );"


def create_credit_card_record():
    while True:
        card_types = ['Visa', 'MasterCard', 'American_Express', 'Discover']
        names = [
            'Jason Levine',
            'Nicole Hoskin',
            'Bob Page',
            'Adam Lopez',
            'Jeff Levy',
            'Rob Baker',
            'Jennifer McDonald',
            'Amber Jones',
            'Oliver James',
            'Sarah Watts',
            'Ruth Collins',
            'Millie Thompson',
            'Joanna Wood',
            'John Smith',
            'Taylor Price',
            'Harley Brown',
            'David Cooper',
            'Leonard Russell',
            'Freddie Matthews',
            'Riley Harrison'
        ]
        card_num = math.ceil((0.1 + 0.9 * random.random()) * (10 ** 16))
        month = random.choice(range(12))
        year = random.choice(range(2022, 2037))

        yield (random.choice(card_types), card_num, month, year, random.choice(names))


def health_fast_execute(connString):
    # run the mssql script queries
    auditPerDBQuery = getAuditPerDBQuery("HealthCaredb")
    queries = [
        "CREATE DATABASE HealthCaredb;",
        "CREATE LOGIN public_health_nurse with password = 'Barbapapa123';",
        "USE HealthCaredb;",
        auditPerDBQuery,
        "CREATE USER public_health_nurse from login public_health_nurse;",
        "GRANT CONNECT TO public_health_nurse;",
        "CREATE TABLE Patient_Info(PatientID int IDENTITY (1, 1) NOT NULL, PatientName nvarchar(50) NOT NULL, BloodType nvarchar(10) NOT NULL, gender nvarchar(10) NOT NULL, InsuranceNum BIGINT NOT NULL, Family_Doctor nvarchar(50));"
    ]
    
    with pyodbc.connect(connString, autocommit=True) as conn:
        with conn.cursor() as crsr:
            for q in queries:
                crsr.execute(q)
            count = 10000
            params = list(islice(create_patient_info_record(), count))
            crsr.fast_executemany = True
            q ='''INSERT INTO Patient_Info values(?, ?, ?, ?, ?)'''
            crsr.executemany(q, params)

    # run the updated mssql queries
    updatedQueries = [
        "USE HealthCaredb;",
        "ALTER TABLE Patient_Info ADD Comments text;"
    ]
    updateCommentsColumn('Patient_Info', 'PatientID', updatedQueries, connString)


def create_patient_info_record():
    while True:
        blood_types = ['A', 'AB', 'B', 'O']
        gender_types = ['F', 'M']
        doctor_names = ['Dr. Dashiel', 'Dr. Yang', 'Dr. Rogers', 'Dr. Stevens', 'Dr. Anderson', 'Dr. Jackson']
        names = [
            'Jason Levine',
            'Nicole Hoskin',
            'Bob Page',
            'Adam Lopez',
            'Jeff Levy',
            'Rob Baker',
            'Jennifer McDonald',
            'Amber Jones',
            'Oliver James',
            'Sarah Watts',
            'Ruth Collins',
            'Millie Thompson',
            'Joanna Wood',
            'John Smith',
            'Taylor Price',
            'Harley Brown',
            'David Cooper',
            'Leonard Russell',
            'Freddie Matthews',
            'Riley Harrison'
        ]
        insurance_num = math.ceil((0.1 + 0.9 * random.random()) * (10 ** 10))
        
        yield (random.choice(names), random.choice(blood_types), random.choice(gender_types), insurance_num, random.choice(doctor_names))


def insurance_fast_execute(connString):
    # run the mssql script queries
    auditPerDBQuery = getAuditPerDBQuery("Insurancedb")
    queries = [
        "CREATE DATABASE Insurancedb;",
        "CREATE LOGIN Broker with password = 'Barbapapa123';",
        "USE Insurancedb;",
        auditPerDBQuery,
        "CREATE USER Broker from login Broker;",
        "GRANT CONNECT TO Broker;",
        "CREATE TABLE InsuranceInfo(PolicyID int IDENTITY (1, 1) NOT NULL, PolicyType nvarchar(50) NOT NULL, PolicyNumber BIGINT NOT NULL, StartMonth int NOT NULL, StartYear int NOT NULL, cust_name nvarchar(50));"
    ]
    
    with pyodbc.connect(connString, autocommit=True) as conn:
        with conn.cursor() as crsr:
            for q in queries:
                crsr.execute(q)
            count = 10000
            params = list(islice(create_insurance_info_record(), count))
            crsr.fast_executemany = True
            q ='''INSERT INTO InsuranceInfo values(?, ?, ?, ?, ?)'''
            crsr.executemany(q, params)

    # run the updated mssql queries
    updatedQueries = [
        "USE Insurancedb;",
        "ALTER TABLE InsuranceInfo ADD Comments text;",
    ]
    updateCommentsColumn('InsuranceInfo', 'PolicyId', updatedQueries, connString)


def create_insurance_info_record():
    while True:
        policy_types = ['Tenant', 'Home', 'Auto', 'Life']
        names = [
            'Jason Levine',
            'Nicole Hoskin',
            'Bob Page',
            'Adam Lopez',
            'Jeff Levy',
            'Rob Baker',
            'Jennifer McDonald',
            'Amber Jones',
            'Oliver James',
            'Sarah Watts',
            'Ruth Collins',
            'Millie Thompson',
            'Joanna Wood',
            'John Smith',
            'Taylor Price',
            'Harley Brown',
            'David Cooper',
            'Leonard Russell',
            'Freddie Matthews',
            'Riley Harrison'
        ]
        policy_num = math.ceil((0.1 + 0.9 * random.random()) * (10 ** 10))
        start_month = random.choice(range(12))
        start_year = random.choice(range(2006, 2021))

        yield (random.choice(policy_types), policy_num, start_month, start_year, random.choice(names))


def telecom_fast_execute(connString):
    # run the mssql script queries
    auditPerDBQuery = getAuditPerDBQuery("telecomdb")
    queries = [
        "CREATE DATABASE telecomdb;",
        "CREATE LOGIN Technician with password = 'Barbapapa123';",
        "USE telecomdb;",
        auditPerDBQuery,
        "CREATE USER Technician from login Technician;",
        "GRANT CONNECT TO Technician;",
        "CREATE TABLE NetworkUsers(UserID int IDENTITY (1, 1) NOT NULL, PlanType nvarchar(50) NOT NULL, IPV4 varchar(20) NOT NULL, UserName nvarchar(50), Password int, Email varchar (50));"
    ]
    
    with pyodbc.connect(connString, autocommit=True) as conn:
        with conn.cursor() as crsr:
            for q in queries:
                crsr.execute(q)
            count = 10000
            params = list(islice(create_network_user_record(), count))
            crsr.fast_executemany = True
            q ='''INSERT INTO NetworkUsers values(?, ?, ?, ?, ?)'''
            crsr.executemany(q, params)

    # run the updated mssql queries
    updatedQueries = [
        "USE telecomdb;",
        "ALTER TABLE NetworkUsers ADD Comments text;",
    ]
    updateCommentsColumn('NetworkUsers', 'UserID', updatedQueries, connString)


def create_network_user_record():
    while True:
        plan_types = ['TV', 'Internet', 'Home Phone', 'Home Security']
        names = {
            'Jason Levine': 'JasonLevine@yahoo.com',
            'Nicole Hoskin': 'icoleHoskin@gmail.com',
            'Bob Page': 'BobPage@hotmail.com',
            'Adam Lopez': 'AdamLopez@gmail.com',
            'Jeff Levy': 'JeffLevy@yahoo.com',
            'Rob Baker': 'RobBaker@gmail.com',
            'Jennifer McDonald': 'JenniferMcDonald@hotmail.com',
            'Amber Jones': 'AmberJones@gmail.com',
            'Oliver James': 'OliverJames@telus.com',
            'Sarah Watts': 'SarahWatts@imperva.com',
            'Ruth Collins': 'RuthCollins@imperva.com',
            'Millie Thompson': 'MillieThompson@gmail.com',
            'Joanna Wood': 'JoannaWood@impeva.com',
            'John Smith': 'JohnSmith@hotmail.com',
            'Taylor Price': 'TaylorPrice@gmail.com',
            'Harley Brown': 'HarleyBrown@yahoo.com',
            'David Cooper': 'DavidCooper@yahoo.com',
            'Leonard Russell': 'LeonardRussell@gmail.com',
            'Freddie Matthews': 'FreddieMatthews@hotmail.com',
            'Riley Harrison': 'RileyHarrison@gmail.com'
        }
        password = math.ceil((0.1 + 0.9 * random.random()) * (10 ** 8))
        ip = str(math.ceil((0.255 * random.random()) * (10 * 3))) + '.' + str(math.ceil(
            (0.255 * random.random()) * (10 * 3))) + '.' + str(math.ceil(
            (0.255 * random.random()) * (10 * 3))) + '.' + str(math.ceil((0.255 * random.random()) * (10 * 3)))
        name = random.choice(list(names))
        yield (random.choice(plan_types), ip, name, password, names[name])


def updateCommentsColumn(tableName, columnName, updatedQueries, connString):
    comments = ['DOB April 08 1982', 'SIN 941 196 421', 'SSN 229-98-9544', 'JoannaW@gmail.com', '5988 Birney Ave, V6S0K4 Vancouver B.C.', '6598 Lincoln Creek, Sacramento CA 95430', '192.168.34.88', 'ec6f:6655:7ff8:4b58:8b8e:81c1:9c7:2648']
    for i in range(0,7):
        num = random.randint(1, 10000)
        query = f"UPDATE {tableName} SET Comments='{comments[i]}' WHERE {columnName}={num};"
        updatedQueries.append(query)

    with pyodbc.connect(connString, autocommit=True) as conn:
        with conn.cursor() as crsr:
            for q in updatedQueries:
                crsr.execute(q)

