import os
import sys
import logging
import pyodbc
import boto3

logger = logging.getLogger()
s3_client = boto3.client("s3")

def lambda_handler(event, context):
    print("beginning of lambda")
    return execute(event)
    

def execute(req):
    # read from s3 bucket
    s3Bucket = os.environ['S3_BUCKET']
    s3Prefix = req["S3_FILE_PREFIX"]

    dbUrl  = os.environ['DB_URI']
    dbPort = os.environ['DB_PORT']

    runFailedLogins(req, dbUrl, dbPort)

    print("Trying to read files with prefix ", s3Prefix, " from s3 bucket ", s3Bucket)
    try:
        response = s3_client.list_objects_v2(Bucket=s3Bucket, Prefix=s3Prefix, StartAfter=s3Prefix)
        s3_files = response["Contents"]
        print("There are ", len(s3_files), " files with prefix ", s3Prefix)

        for s3_file in s3_files:
            fileName = s3_file["Key"]
            print("Trying to read file ", fileName, " from s3")
            iterator = s3_client.get_object(Bucket=s3Bucket, Key=s3_file["Key"])["Body"].iter_lines()
            print("SUCCESS: Succeeded to read file from s3")
            
            # get db user to connetc to db
            dbUser = getDbUser(req, fileName)
            dbPwd = getDbPwd(req, fileName)
            
            runQueriesOnDb(dbUrl, dbPort, dbUser, dbPwd, iterator)
    except Exception as e:
        print("exception is: ", e)
        

def runQueriesOnDb(dbUrl, dbPort, dbUser, dbPwd, s3FileIterator):
    dbName = os.environ['DB_NAME']
    # dbPwd  = os.environ['DB_PWD']

    # run quesries on MsSQL
    conn = pyodbc.connect("DRIVER={ODBC Driver 17 for SQL Server}; SERVER="+dbUrl+";PORT="+dbPort+";DATABASE="+dbName+";UID="+dbUser+";PWD="+dbPwd+"", autocommit=True)
    print("SUCCESS: Connection to SQLSERVER instance succeeded")
    
    # run the mssql script quesries
    crsr = conn.cursor()
    
    sqlQuery = ''
    for line in s3FileIterator:
        line = line.decode('utf-8')
        if line == 'GO':
            print("Going to execute:")
            print(sqlQuery)
            try:
                crsr.execute(sqlQuery)
            except pyodbc.ProgrammingError as ex:
                print("got an error", ex)
                if 'permission was denied on object' in str(ex):
                    print("user has no permissions to execute the statement. continue")
                else:
                    raise

            try:
                print("rowcount is ", crsr.rowcount)
                print("going to fetchall")
                
                result = crsr.fetchall()
                print("result of fetchall is ", len(result))
            except pyodbc.ProgrammingError as ex:
                print("got an error:", ex)

            sqlQuery = ''
        else:
            sqlQuery = sqlQuery + line + '\n'

    conn.commit()

    print("Succeeded to execute sql statements")
    
    crsr.close()
    conn.close()


def runFailedLogins(req, dbUrl, dbPort):
    if 'SHOULD_RUN_FAILED_LOGINS' not in req:
        return 

    print("Going to run failed logins on DBs")
    users = ['admin', 'admin', 'Admin', 'administrator', 'manager']

    dbsFailedLogins = req['DBS_FAILED_LOGINS'].split(";")
    for dbName in dbsFailedLogins:
        print("Going to run failed logins on db ", dbName)
        for user in users:
            try:
                conn = pyodbc.connect("DRIVER={ODBC Driver 17 for SQL Server}; SERVER="+dbUrl+";PORT="+dbPort+";DATABASE="+dbName+";UID="+user+";PWD=wrongpass")
            except Exception as ex:
                print("Exception is ", ex)


def getDbUser(req, fileName):
    dbUser = os.environ['DB_USER']
    if 'DB_USER2' not in req:
        return dbUser

    dbUser2 = req['DB_USER2']
    if "2" in fileName:
        print("fileName contains '2'. fileName is ", fileName)

        usersDict = dict(x.split(":") for x in dbUser2.split(";"))
        print("dict is ", usersDict)
        for k,v in usersDict.items():
            if k in fileName:
                dbUser = v
                break

    print("dbUser is ", dbUser)
    return dbUser

def getDbPwd(req, fileName):
    dbPwd = os.environ['DB_PWD']
    if 'DB_USER2' not in req:
        return dbPwd

    if "2" in fileName:
        print("fileName contains '2'. fileName is ", fileName)
        dbPwd = "Barbapapa123"

    print("dbPwd is ", dbPwd)
    return dbPwd