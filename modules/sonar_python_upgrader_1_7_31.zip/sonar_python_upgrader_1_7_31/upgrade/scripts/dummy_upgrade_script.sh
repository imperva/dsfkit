#!/bin/bash

ls -l /home

echo "Dummy Upgrade completed"
