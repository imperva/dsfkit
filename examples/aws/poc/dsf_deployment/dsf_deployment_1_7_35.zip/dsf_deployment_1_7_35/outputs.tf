output "dsf_deployment_name" {
  value = local.deployment_name_salted
}

output "dsf_private_ssh_key" {
  sensitive = true
  value     = try(module.key_pair.private_key_content, null)
}

output "dsf_private_ssh_key_file_path" {
  value = local.private_key_file_path
}

output "generated_network" {
  value = try({
    vpc             = module.vpc[0].vpc_id
    public_subnets  = module.vpc[0].public_subnets
    private_subnets = module.vpc[0].private_subnets
  }, null)
}

output "sonar" {
  value = var.enable_sonar ? {
    hub_main = {
      public_ip    = try(module.hub_main[0].public_ip, null)
      public_dns   = try(module.hub_main[0].public_dns, null)
      private_ip   = try(module.hub_main[0].private_ip, null)
      private_dns  = try(module.hub_main[0].private_dns, null)
      jsonar_uid   = try(module.hub_main[0].jsonar_uid, null)
      display_name = try(module.hub_main[0].display_name, null)
      role_arn     = try(module.hub_main[0].iam_role, null)
      ssh_command  = try("ssh -i ${local.private_key_file_path} ${module.hub_main[0].ssh_user}@${local.dns_hub_main}", null)
      tokens       = nonsensitive(module.hub_main[0].access_tokens)
    }
    hub_dr = var.hub_hadr ? {
      public_ip    = try(module.hub_dr[0].public_ip, null)
      public_dns   = try(module.hub_dr[0].public_dns, null)
      private_ip   = try(module.hub_dr[0].private_ip, null)
      private_dns  = try(module.hub_dr[0].private_dns, null)
      jsonar_uid   = try(module.hub_dr[0].jsonar_uid, null)
      display_name = try(module.hub_dr[0].display_name, null)
      role_arn     = try(module.hub_dr[0].iam_role, null)
      ssh_command  = try("ssh -i ${local.private_key_file_path} ${module.hub_dr[0].ssh_user}@${local.dns_hub_dr}", null)
    } : null
    agentless_gw_main = [
      for idx, val in module.agentless_gw_main :
      {
        private_ip   = try(val.private_ip, null)
        private_dns  = try(val.private_dns, null)
        jsonar_uid   = try(val.jsonar_uid, null)
        display_name = try(val.display_name, null)
        role_arn     = try(val.iam_role, null)
        ssh_command  = try("ssh -o ProxyCommand='ssh -o UserKnownHostsFile=/dev/null -i ${local.private_key_file_path} -W %h:%p ${module.hub_main[0].ssh_user}@${local.dns_hub_main}' -i ${local.private_key_file_path} ${val.ssh_user}@${val.private_ip}", null)
      }
    ]
    agentless_gw_dr = var.agentless_gw_hadr ? [
      for idx, val in module.agentless_gw_dr :
      {
        private_ip   = try(val.private_ip, null)
        private_dns  = try(val.private_dns, null)
        jsonar_uid   = try(val.jsonar_uid, null)
        display_name = try(val.display_name, null)
        role_arn     = try(val.iam_role, null)
        ssh_command  = try("ssh -o ProxyCommand='ssh -o UserKnownHostsFile=/dev/null -i ${local.private_key_file_path} -W %h:%p ${module.hub_main[0].ssh_user}@${local.dns_hub_main}' -i ${local.private_key_file_path} ${val.ssh_user}@${val.private_ip}", null)
      }
    ] : []
  } : null
}

output "dam" {
  value = var.enable_dam ? {
    mx = {
      public_ip        = try(module.mx[0].public_ip, null)
      public_dns       = try(module.mx[0].public_dns, null)
      private_ip       = try(module.mx[0].private_ip, null)
      private_dns      = try(module.mx[0].private_dns, null)
      display_name     = try(module.mx[0].display_name, null)
      role_arn         = try(module.mx[0].iam_role, null)
      ssh_command      = try("ssh -i ${local.private_key_file_path} ${module.mx[0].ssh_user}@${local.dns_mx}", null)
      public_url       = try(join("", ["https://", local.dns_mx, ":8083/"]), null)
      private_url      = try(join("", ["https://", module.mx[0].private_dns, ":8083/"]), null)
      password         = nonsensitive(local.password)
      user             = module.mx[0].web_console_user
      large_scale_mode = module.mx[0].large_scale_mode
    }
    agent_gw = [
      for idx, val in module.agent_gw : {
        private_ip       = try(val.private_ip, null)
        private_dns      = try(val.private_dns, null)
        public_ip        = try(val.public_ip, null)
        public_dns       = try(val.public_dns, null)
        display_name     = try(val.display_name, null)
        role_arn         = try(val.iam_role, null)
        group_id         = try(val.group_id, null)
        ssh_command      = try("ssh -o UserKnownHostsFile=/dev/null -o ProxyCommand='ssh -o UserKnownHostsFile=/dev/null -i ${local.private_key_file_path} -W %h:%p ${module.mx[0].ssh_user}@${local.dns_mx}' -i ${local.private_key_file_path} ${val.ssh_user}@${val.private_ip}", null)
        large_scale_mode = val.large_scale_mode
      }
    ]
  } : null
}

output "dra" {
  value = var.enable_dra ? {
    admin_server = {
      public_ip    = try(module.dra_admin[0].public_ip, null)
      public_dns   = try(module.dra_admin[0].public_dns, null)
      private_ip   = try(module.dra_admin[0].private_ip, null)
      private_dns  = try(module.dra_admin[0].private_dns, null)
      display_name = try(module.dra_admin[0].display_name, null)
      role_arn     = try(module.dra_admin[0].iam_role, null)
      ssh_command  = try("ssh -i ${local.private_key_file_path} ${module.dra_admin[0].ssh_user}@${local.dns_dra_admin}", null)
    }
    analytics = [
      for idx, val in module.dra_analytics : {
        private_ip    = val.private_ip
        private_dns   = val.private_dns
        archiver_user = val.archiver_user
        ssh_command   = try("ssh -o UserKnownHostsFile=/dev/null -o ProxyCommand='ssh -o UserKnownHostsFile=/dev/null -i ${local.private_key_file_path} -W %h:%p ${module.dra_admin[0].ssh_user}@${local.dns_dra_admin}' -i ${local.private_key_file_path} ${val.ssh_user}@${val.private_ip}", null)
      }
    ]
  } : null
}

output "ciphertrust" {
  value = var.enable_ciphertrust ? {
    ciphertrust_manager = [
      for idx, val in module.ciphertrust_manager : {
        private_ip   = try(val.private_ip, null)
        private_dns  = try(val.private_dns, null)
        public_ip    = try(val.public_ip, null)
        public_dns   = try(val.public_dns, null)
        public_url   = try(join("", ["https://", local.dns_enabled ? "${local.deployment_name_salted}-cm-${idx}.${var.dns_zone_domain}" : val.public_dns]), null)
        private_url  = try(join("", ["https://", val.private_dns]), null)
        display_name = try(val.display_name, null)
        ssh_command  = try("ssh -i ${local.private_key_file_path} ${val.ssh_user}@${local.dns_enabled ? "${local.deployment_name_salted}-cm-${idx}.${var.dns_zone_domain}" : val.public_dns}", null)
      }
    ]
  } : null
}

output "cte_ddc_agents" {
  value = var.enable_ciphertrust ? {
    cte_agents = [
      for val in concat(local.linux_cte_only_instances, local.windows_cte_only_instances) :
      {
        private_ip   = module.cte_ddc_agents[val.id].private_ip
        private_dns  = module.cte_ddc_agents[val.id].private_dns
        public_ip    = module.cte_ddc_agents[val.id].public_ip
        public_dns   = module.cte_ddc_agents[val.id].public_dns
        display_name = try(module.cte_ddc_agents[val.id].display_name, null)
        ssh_command  = try("ssh -i ${local.private_key_file_path} ${module.cte_ddc_agents[val.id].ssh_user}@${local.dns_enabled ? "${local.deployment_name_salted}-${val.id}.${var.dns_zone_domain}" : module.cte_ddc_agents[val.id].public_ip}", null)
      }
    ]
    ddc_agents = [
      for val in concat(local.linux_ddc_only_instances, local.windows_ddc_only_instances) :
      {
        private_ip   = module.cte_ddc_agents[val.id].private_ip
        private_dns  = module.cte_ddc_agents[val.id].private_dns
        public_ip    = module.cte_ddc_agents[val.id].public_ip
        public_dns   = module.cte_ddc_agents[val.id].public_dns
        display_name = try(module.cte_ddc_agents[val.id].display_name, null)
        ssh_command  = try("ssh -i ${local.private_key_file_path} ${module.cte_ddc_agents[val.id].ssh_user}@${local.dns_enabled ? "${local.deployment_name_salted}-${val.id}.${var.dns_zone_domain}" : module.cte_ddc_agents[val.id].public_ip}", null)
      }
    ]
    cte_ddc_agents = [
      for val in concat(local.linux_cte_ddc_instances, local.windows_cte_ddc_instances) :
      {
        private_ip   = module.cte_ddc_agents[val.id].private_ip
        private_dns  = module.cte_ddc_agents[val.id].private_dns
        public_ip    = module.cte_ddc_agents[val.id].public_ip
        public_dns   = module.cte_ddc_agents[val.id].public_dns
        display_name = try(module.cte_ddc_agents[val.id].display_name, null)
        ssh_command  = try("ssh -i ${local.private_key_file_path} ${module.cte_ddc_agents[val.id].ssh_user}@${local.dns_enabled ? "${local.deployment_name_salted}-${val.id}.${var.dns_zone_domain}" : module.cte_ddc_agents[val.id].public_ip}", null)
      }
    ]
  } : null
}

output "audit_sources" {
  value = {
    agent_sources = [
      for idx, val in module.db_with_agent :
      {
        private_ip  = val.private_ip
        private_dns = val.private_dns
        db_type     = val.db_type
        os_type     = val.os_type
        ssh_command = try("ssh -o UserKnownHostsFile=/dev/null -o ProxyCommand='ssh -o UserKnownHostsFile=/dev/null -i ${local.private_key_file_path} -W %h:%p ${module.mx[0].ssh_user}@${local.dns_mx}' -i ${local.private_key_file_path} ${val.ssh_user}@${val.private_ip}", null)
      }
    ]
    agentless_sources = var.enable_sonar ? {
      rds_mysql    = try(module.rds_mysql[0], null)
      rds_postgres = try(module.rds_postgres[0], null)
      rds_mssql    = try(module.rds_mssql[0], null)
    } : null
  }
}

output "web_console_dsf_hub" {
  value = try({
    user        = module.hub_main[0].web_console_user
    password    = nonsensitive(local.password)
    public_url  = join("", ["https://", local.dns_hub_main, ":8443/"])
    private_url = join("", ["https://", module.hub_main[0].private_dns, ":8443/"])
  }, null)
}

output "web_console_dra" {
  value = try({
    public_url  = join("", ["https://", local.dns_dra_admin, ":8443/"])
    private_url = join("", ["https://", module.dra_admin[0].private_dns, ":8443/"])
  }, null)
}

output "web_console_dam" {
  value = try({
    public_url  = join("", ["https://", local.dns_mx, ":8083/"])
    private_url = join("", ["https://", module.mx[0].private_dns, ":8083/"])
    password    = nonsensitive(local.password)
    user        = module.mx[0].web_console_user
  }, null)
}

output "web_console_ciphertrust" {
  value = try({
    public_url  = join("", ["https://", local.dns_enabled ? "${local.deployment_name_salted}-cm-0.${var.dns_zone_domain}" : module.ciphertrust_manager[0].public_dns])
    private_url = join("", ["https://", module.ciphertrust_manager[0].private_dns])
    password    = nonsensitive(local.password)
    user        = local.ciphertrust_manager_web_console_username
  }, null)
}

output "dns_records" {
  description = "DNS CNAME records for all public-facing instances. Shows records that need to exist for zScaler access."
  value = local.dns_enabled ? {
    for suffix, target in local.dns_record_targets :
    "${local.deployment_name_salted}-${suffix}.${var.dns_zone_domain}" => {
      type         = "CNAME"
      target       = target
      auto_created = local.dns_auto_create
    }
  } : {}
}

output "fam_classification_integration_resources" {
  value = try({
    scan_results_bucket_name                   = aws_s3_bucket.fam_scan_results_bucket[0].id
    scan_results_bucket_notifications_sqs_name = aws_sqs_queue.fam_scan_results_bucket_notifications_sqs[0].name
    classification_integration_iam_policy      = aws_iam_policy.fam_classification_integration_policy[0].name
  }, null)
}
