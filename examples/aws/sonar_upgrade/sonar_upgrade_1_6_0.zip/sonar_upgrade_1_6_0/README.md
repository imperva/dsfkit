# DSF Hub and Agentless Gateway Upgrade example
[![GitHub tag](https://img.shields.io/github/v/tag/imperva/dsfkit.svg)](https://github.com/imperva/dsfkit/tags)

**Alpha release**

A DSF Hub and Agentless Gateway (formerly Sonar) upgrade example.

Refer to the main [README](https://github.com/imperva/dsfkit#upgrade) for instructions on how to run this example.